-- Backup created: 2026-01-19T14:09:17.155184
-- Schemas: public, invoice, inventory, scriptclient, audit_sales, ads_alert


-- Schema: public
CREATE SCHEMA IF NOT EXISTS "public";


-- Table: public.account_lockout
CREATE TABLE IF NOT EXISTS "public"."account_lockout" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "ip_address" VARCHAR(45),
    "lockout_reason" VARCHAR(255) NOT NULL,
    "failed_attempts_count" INTEGER DEFAULT 0 NOT NULL,
    "locked_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "unlock_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "unlocked_at" TIMESTAMP WITH TIME ZONE,
    "unlocked_by" VARCHAR(255),
    PRIMARY KEY ("id")
);

-- Table: public.ad_token
CREATE TABLE IF NOT EXISTS "public"."ad_token" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "platform" PLATFORM NOT NULL,
    "account_ref" VARCHAR(255),
    "account_name" VARCHAR(255),
    "access_token_enc" VARCHAR NOT NULL,
    "refresh_token_enc" VARCHAR,
    "scope" VARCHAR,
    "expires_at" TIMESTAMP WITHOUT TIME ZONE,
    "is_valid" BOOLEAN NOT NULL,
    "last_validated" TIMESTAMP WITHOUT TIME ZONE,
    "meta" JSON,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "user_id" UUID NOT NULL,
    "deleted_at" TIMESTAMP WITHOUT TIME ZONE,
    "social_identity_id" UUID,
    "facebook_page_id" UUID,
    "token_type" TOKEN_TYPE_ENUM NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."ad_token" ("id", "tenant_id", "platform", "account_ref", "account_name", "access_token_enc", "refresh_token_enc", "scope", "expires_at", "is_valid", "last_validated", "meta", "created_at", "updated_at", "user_id", "deleted_at", "social_identity_id", "facebook_page_id", "token_type") VALUES ('945c18fc-fbbf-4c9d-8cae-f7461ff228fe', '62644a78-bc22-4833-b032-d8f080beb3be', 'facebook', '1500642824495201', 'Chan Cashing', 'gAAAAABpW2lbjq1Sp4FX51UAShJUas9K2LF2pCaHzZs677-x_Hyz4JjewM47wXaXnp5zI1MHJRimlFLo36PjmVSaP1pUvRjVpljhjpFoCWzGC83wsz30gnywIKZWeX0ImmXQUbwd8Bp_E7899r8Km7bUESGQRVf-eUDyEvnIAdBDZgKcvg0VzbF0odAPbQsw9UWTcok02tSze-YVFIOoWBA84dqPfgrf5vTSP9B5Jj9GhZnxYlJCmKNdd-PkknR3P9-8Ht3eOQ0-BxvOfh4hu3tYd_caF-O6ztfouYu5iNrTa1ZpJqhE5D54T53zTHFa1pv__cD9HVs1bBnIW2u3aAHEFuZTXX-ZWQ==', NULL, 'public_profile,ads_read,pages_read_engagement,email', NULL, True, NULL, '{"short": {"access_token": "EAAK7YaqpWO8BQW3eylklrY4nZCGar0ZBhgxvJZB1ZCwKZBYjB230LAB3HqwgrqQb7OIrgw1tZAfHS8N2XstGr1sCZCA8ZARtPaoOi05Lin2rFcYr1wDMaQjUdWthDiguoIAGKQWSUO7S4BjG1S2OL95b2eMFbZCE6Ozhb2l7jUNUlDKwNEBxnAoTSi68PeOu8hfjwS94FFOdE1y2KY1ZCJoCWVK4JLmpzMFAZCKrIE5hBeXFoqglufhL9TGCFSR9IxIfGyKqMOX69oCcUcc8m96ZCwm7t030fwJvY327", "token_type": "bearer"}, "long": {"access_token": "EAAK7YaqpWO8BQWOP1Tc0noZAXR1HXye5cWDwghtZAH5TnKngCeeTl8ieFb9TsGoYUVlilr6WGXSxGn2pmx0q0PoWOwCdlcBOgOPku5b5ZC1SfKayPQntREe447lZAyNaN95IrZAgCVKhahS7MO8ps2GREhU7AuPZCmIsNCG9CrvpAdsEGIpDUThEfwuOxZC", "token_type": "bearer"}, "user": {"id": "1500642824495201", "name": "Chan Cashing"}, "pages": [{"id": "1943575625871835", "name": "\u1798\u17c9\u17b6\u1780\u17cb\u1798\u17c9\u17b6\u1780\u17cb\u179b\u1780\u17cb\u1795\u17d2\u1791\u17c7\u1793\u17b7\u1784\u178a\u17b8\u17a1\u17bc\u178f\u17cd", "access_token": "EAAK7YaqpWO8BQRQr8GD2ULCOscgjxq6HQKQgpVAkHOufMQZBZBkxokSjjcHoZClC2Se5Vg0pvzFbpYTjS0YHXOUdFxYpFZCalSJ5OLPU9AumZAW5Yi6CXGw29pBMZCVSkfJcQl1ktYCdloU3AvkiaxOLYyPzjgN30Nm8wzlxCAJDPzm2iQY4pUPrUS2I0cQgUewhVC", "category": "Real Estate Company", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT", "MANAGE"]}, {"id": "103529078957349", "name": "JD Garage - \u8f66\u5e93", "access_token": "EAAK7YaqpWO8BQYq3YOcTEVGGyWNPk9fptkQc39jn6i5Cz2KDYQN8aH0CxkuTX00jofAGjP2MTZAWDeTeKZBZBQZAhm3xxrh8Kx0r5zIuz0mpLVFEZBv8iBiGYAARWULvmJ1ftbNt4TQ74BkkHlTkGkyvwD7P1r5XrOiBP7FYSZBRyZAMTJvnttDzTt21aoRl22aZC0cZD", "category": "Business Center", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT"]}]}', '2026-01-05T07:33:48.017745', '2026-01-05T07:33:48.017750', '51e61235-0326-4739-997e-c48fd9e44bcc', NULL, '44cd55f5-438e-4d06-952c-c3eac9892b02', NULL, 'user');
INSERT INTO "public"."ad_token" ("id", "tenant_id", "platform", "account_ref", "account_name", "access_token_enc", "refresh_token_enc", "scope", "expires_at", "is_valid", "last_validated", "meta", "created_at", "updated_at", "user_id", "deleted_at", "social_identity_id", "facebook_page_id", "token_type") VALUES ('4f7f5175-7549-4eaf-94db-d3679b3083f1', '62644a78-bc22-4833-b032-d8f080beb3be', 'facebook', 'page_1943575625871835', 'ម៉ាក់ម៉ាក់លក់ផ្ទះនិងដីឡូត៍', 'gAAAAABpW2lca3PYGz2WE0nfeVeEMijOEcbLaflCWxGxwrxnsuCXDvKBCHqz7gis2nzG166m6QRw81pXLuP7whZ9ZJ-ozGIAYIbEWkHvTbPRsWJzjPoGkZ4-JKa-TOOosc3IoJRhDHIzx9V5hQIfitXD_pJjnAEuybssj6crfOzMjc0_mJatfklV5Bgt0EEtEzexyQG5_iZPW_sOzMIbQKlvvdxWrQNmrAQI882iVD0A0qrufQ0jNsjzEHk23Onl4_w3SHhwuKlPCyFQvYYSqoFj7boRq5aPq68ikPYu8Hfhd5lKcyKEut_GqM_qzEvVTwHfPou76hAHCiWGEryc8PEp2lJoVPv5dQ==', NULL, 'pages_manage_posts,pages_read_engagement', NULL, True, NULL, '{"id": "1943575625871835", "name": "\u1798\u17c9\u17b6\u1780\u17cb\u1798\u17c9\u17b6\u1780\u17cb\u179b\u1780\u17cb\u1795\u17d2\u1791\u17c7\u1793\u17b7\u1784\u178a\u17b8\u17a1\u17bc\u178f\u17cd", "access_token": "EAAK7YaqpWO8BQRQr8GD2ULCOscgjxq6HQKQgpVAkHOufMQZBZBkxokSjjcHoZClC2Se5Vg0pvzFbpYTjS0YHXOUdFxYpFZCalSJ5OLPU9AumZAW5Yi6CXGw29pBMZCVSkfJcQl1ktYCdloU3AvkiaxOLYyPzjgN30Nm8wzlxCAJDPzm2iQY4pUPrUS2I0cQgUewhVC", "category": "Real Estate Company", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT", "MANAGE"]}', '2026-01-05T07:33:48.062572', '2026-01-05T07:33:48.062575', '51e61235-0326-4739-997e-c48fd9e44bcc', NULL, '44cd55f5-438e-4d06-952c-c3eac9892b02', 'b6f30956-f5e8-4614-9bc5-8be67f4fa374', 'page');
INSERT INTO "public"."ad_token" ("id", "tenant_id", "platform", "account_ref", "account_name", "access_token_enc", "refresh_token_enc", "scope", "expires_at", "is_valid", "last_validated", "meta", "created_at", "updated_at", "user_id", "deleted_at", "social_identity_id", "facebook_page_id", "token_type") VALUES ('9fae9d69-e3d3-42de-b643-dd636772e7c9', '62644a78-bc22-4833-b032-d8f080beb3be', 'facebook', 'page_103529078957349', 'JD Garage - 车库', 'gAAAAABpW2lcjazyrfJQiVw68-FoRIyy4N9y4QRHIn1kCMkghLN-Z_B_eKCeQpNLGtzJAQ-cUh1zjXufnHDzTN9ypmVNl27oGsXEbNOtMR_ffO6YXl1vNLANvBVXisSMDTTh5A9zExQcFuTNM8BSKDnordO3CGMpft_u4z3KKvr844iNMv-2D7jMnrP4RGaQVrlTqIbqq3inr1rrS1DwH7Zy4wRTBQvPEFaZtyQqfOa22ZCMLZBzGGl6B2lYLKR8OqSpEOXirMjzqWpLOkxbSUBYq2dCNdDQxLCqaOxEHFFhMtm9u_D5ecrumg5W1HmOGrCV-27ykpjpc9C_CehiAogx3p5M0zCb6w==', NULL, 'pages_manage_posts,pages_read_engagement', NULL, True, NULL, '{"id": "103529078957349", "name": "JD Garage - \u8f66\u5e93", "access_token": "EAAK7YaqpWO8BQYq3YOcTEVGGyWNPk9fptkQc39jn6i5Cz2KDYQN8aH0CxkuTX00jofAGjP2MTZAWDeTeKZBZBQZAhm3xxrh8Kx0r5zIuz0mpLVFEZBv8iBiGYAARWULvmJ1ftbNt4TQ74BkkHlTkGkyvwD7P1r5XrOiBP7FYSZBRyZAMTJvnttDzTt21aoRl22aZC0cZD", "category": "Business Center", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT"]}', '2026-01-05T07:33:48.084164', '2026-01-05T07:33:48.084168', '51e61235-0326-4739-997e-c48fd9e44bcc', NULL, '44cd55f5-438e-4d06-952c-c3eac9892b02', '88cc20fb-bf3c-49aa-be33-55ad276ab68a', 'page');

-- Table: public.alembic_version
CREATE TABLE IF NOT EXISTS "public"."alembic_version" (
    "version_num" VARCHAR(32) NOT NULL,
    PRIMARY KEY ("version_num")
);
INSERT INTO "public"."alembic_version" ("version_num") VALUES ('s9n0o1p2q3r4');

-- Table: public.automation
CREATE TABLE IF NOT EXISTS "public"."automation" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "destination_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "type" AUTOMATIONTYPE NOT NULL,
    "status" AUTOMATIONSTATUS NOT NULL,
    "schedule_config" JSON,
    "automation_config" JSON NOT NULL,
    "platforms" JSON,
    "last_run" TIMESTAMP WITHOUT TIME ZONE,
    "next_run" TIMESTAMP WITHOUT TIME ZONE,
    "run_count" INTEGER NOT NULL,
    "error_count" INTEGER NOT NULL,
    "last_error" TEXT,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: public.automation_run
CREATE TABLE IF NOT EXISTS "public"."automation_run" (
    "id" UUID NOT NULL,
    "automation_id" UUID NOT NULL,
    "started_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "completed_at" TIMESTAMP WITHOUT TIME ZONE,
    "status" VARCHAR(50) NOT NULL,
    "result" JSON,
    "error_message" TEXT,
    "logs" JSON,
    PRIMARY KEY ("id")
);

-- Table: public.destination
CREATE TABLE IF NOT EXISTS "public"."destination" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "type" DESTINATIONTYPE NOT NULL,
    "config" JSON NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: public.email_verification_token
CREATE TABLE IF NOT EXISTS "public"."email_verification_token" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token" VARCHAR(64) NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "used_at" TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('bf459260-ac1c-428b-b152-7caa5925c643', '51e61235-0326-4739-997e-c48fd9e44bcc', '8b66f21329b2938c84009b75a625eddc3f944fb132b61f4842c16d469e13e117', '2026-01-17T05:57:41.915477+00:00', '2026-01-16T05:57:41.917928+00:00', '2026-01-16T06:19:55.390266+00:00');
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('c920beba-5934-4485-8ef7-58b016080402', '51e61235-0326-4739-997e-c48fd9e44bcc', 'b0ddd09354f6573bad46244101694621f7b1ef455317eed094fbd2198eaa214b', '2026-01-17T06:19:55.489284+00:00', '2026-01-16T06:19:55.490020+00:00', '2026-01-16T06:31:08.169253+00:00');
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('3c5d6b2d-fb30-406f-b731-e170f17e4620', '51e61235-0326-4739-997e-c48fd9e44bcc', 'ce107e0ed1ac8ab864b5c86003654184128d21c04c2e05d95a11dbabb1fc6481', '2026-01-17T06:31:08.271039+00:00', '2026-01-16T06:31:08.271946+00:00', '2026-01-16T06:31:19.476118+00:00');
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('7f32daab-8733-4ebb-818b-337f6ac44576', '51e61235-0326-4739-997e-c48fd9e44bcc', '95251d5a40f0e1abfb477ed58d7b8a993652e2766e6d3f6c4c3fa4ae15ad6c6c', '2026-01-17T06:31:19.522011+00:00', '2026-01-16T06:31:19.522779+00:00', '2026-01-16T06:34:44.792657+00:00');
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('59119b66-8699-4b26-b00a-19ac4e691244', '51e61235-0326-4739-997e-c48fd9e44bcc', '108205dd53cdb4d2b1ff9649f874f067d656261a94c8732da272998eb84103aa', '2026-01-17T06:34:44.957760+00:00', '2026-01-16T06:34:44.960215+00:00', '2026-01-16T06:47:16.973325+00:00');
INSERT INTO "public"."email_verification_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('3500a72f-8588-4149-8ffd-8c1e14d70c22', '51e61235-0326-4739-997e-c48fd9e44bcc', '92b76e1032131e45c4224751f43796f2bf722a1a1d58b88cb59bbe50e5ead919', '2026-01-17T06:47:17.167504+00:00', '2026-01-16T06:47:17.170657+00:00', NULL);

-- Table: public.facebook_page
CREATE TABLE IF NOT EXISTS "public"."facebook_page" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "social_identity_id" UUID NOT NULL,
    "page_id" VARCHAR(255) NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "category" VARCHAR(255),
    "tasks" _varchar[],
    "page_data" JSONB,
    "is_active" BOOLEAN DEFAULT true NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."facebook_page" ("id", "social_identity_id", "page_id", "name", "category", "tasks", "page_data", "is_active", "created_at", "updated_at") VALUES ('b6f30956-f5e8-4614-9bc5-8be67f4fa374', '44cd55f5-438e-4d06-952c-c3eac9892b02', '1943575625871835', 'ម៉ាក់ម៉ាក់លក់ផ្ទះនិងដីឡូត៍', 'Real Estate Company', '["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT", "MANAGE"]', '{"id": "1943575625871835", "name": "\u1798\u17c9\u17b6\u1780\u17cb\u1798\u17c9\u17b6\u1780\u17cb\u179b\u1780\u17cb\u1795\u17d2\u1791\u17c7\u1793\u17b7\u1784\u178a\u17b8\u17a1\u17bc\u178f\u17cd", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT", "MANAGE"], "category": "Real Estate Company", "access_token": "EAAK7YaqpWO8BQRQr8GD2ULCOscgjxq6HQKQgpVAkHOufMQZBZBkxokSjjcHoZClC2Se5Vg0pvzFbpYTjS0YHXOUdFxYpFZCalSJ5OLPU9AumZAW5Yi6CXGw29pBMZCVSkfJcQl1ktYCdloU3AvkiaxOLYyPzjgN30Nm8wzlxCAJDPzm2iQY4pUPrUS2I0cQgUewhVC"}', True, '2026-01-05T07:33:48.046793', '2026-01-05T07:33:48.046798');
INSERT INTO "public"."facebook_page" ("id", "social_identity_id", "page_id", "name", "category", "tasks", "page_data", "is_active", "created_at", "updated_at") VALUES ('88cc20fb-bf3c-49aa-be33-55ad276ab68a', '44cd55f5-438e-4d06-952c-c3eac9892b02', '103529078957349', 'JD Garage - 车库', 'Business Center', '["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT"]', '{"id": "103529078957349", "name": "JD Garage - \u8f66\u5e93", "tasks": ["MODERATE", "MESSAGING", "ANALYZE", "ADVERTISE", "CREATE_CONTENT"], "category": "Business Center", "access_token": "EAAK7YaqpWO8BQYq3YOcTEVGGyWNPk9fptkQc39jn6i5Cz2KDYQN8aH0CxkuTX00jofAGjP2MTZAWDeTeKZBZBQZAhm3xxrh8Kx0r5zIuz0mpLVFEZBv8iBiGYAARWULvmJ1ftbNt4TQ74BkkHlTkGkyvwD7P1r5XrOiBP7FYSZBRyZAMTJvnttDzTt21aoRl22aZC0cZD"}', True, '2026-01-05T07:33:48.073417', '2026-01-05T07:33:48.073426');

-- Table: public.ip_access_rule
CREATE TABLE IF NOT EXISTS "public"."ip_access_rule" (
    "id" UUID NOT NULL,
    "ip_address" VARCHAR(45) NOT NULL,
    "rule_type" IPRULETYPE NOT NULL,
    "reason" TEXT,
    "expires_at" TIMESTAMP WITHOUT TIME ZONE,
    "is_active" BOOLEAN DEFAULT true NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    "created_by" VARCHAR(255),
    PRIMARY KEY ("id")
);

-- Table: public.login_attempt
CREATE TABLE IF NOT EXISTS "public"."login_attempt" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "ip_address" VARCHAR(45) NOT NULL,
    "user_agent" TEXT,
    "result" LOGINATTTEMPTRESULT NOT NULL,
    "failure_reason" VARCHAR(255),
    "attempted_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: public.password_reset_token
CREATE TABLE IF NOT EXISTS "public"."password_reset_token" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token" VARCHAR(64) NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "used_at" TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."password_reset_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('91e017de-bc2a-446f-b1a5-ae65416b1134', '51e61235-0326-4739-997e-c48fd9e44bcc', '4fde2d0e063970033dcd73606ae06a27401255fe299fd7a3fcdbd422d8654bb0', '2026-01-16T06:39:28.662175+00:00', '2026-01-16T05:39:28.664932+00:00', '2026-01-16T05:58:02.945111+00:00');
INSERT INTO "public"."password_reset_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('ce22ad75-27e9-425f-a024-f70a1c9f0119', '51e61235-0326-4739-997e-c48fd9e44bcc', '2ebfd6aff95b0cc2b25122dd196dfb9de007697bb92a191a25e3691af8e79375', '2026-01-16T06:58:03.110865+00:00', '2026-01-16T05:58:03.111706+00:00', '2026-01-16T06:18:28.754918+00:00');
INSERT INTO "public"."password_reset_token" ("id", "user_id", "token", "expires_at", "created_at", "used_at") VALUES ('1bb7a755-514e-4510-95a5-9b4b5374ce1c', '51e61235-0326-4739-997e-c48fd9e44bcc', '2fa3e21278e96f5b1dc8d53a719f959fae5ce843a4bbfac6dd7f34590b1fe215', '2026-01-16T07:18:28.857529+00:00', '2026-01-16T06:18:28.858183+00:00', NULL);

-- Table: public.rate_limit_violation
CREATE TABLE IF NOT EXISTS "public"."rate_limit_violation" (
    "id" UUID NOT NULL,
    "ip_address" VARCHAR(45) NOT NULL,
    "endpoint" VARCHAR(500) NOT NULL,
    "violation_count" INTEGER DEFAULT 1 NOT NULL,
    "last_violation_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    "auto_banned" BOOLEAN DEFAULT false NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: public.refresh_token
CREATE TABLE IF NOT EXISTS "public"."refresh_token" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "user_id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "token_hash" VARCHAR(64) NOT NULL,
    "family_id" UUID NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "revoked_at" TIMESTAMP WITH TIME ZONE,
    "replaced_by_id" UUID,
    "device_info" VARCHAR(255),
    "ip_address" VARCHAR(45),
    PRIMARY KEY ("id")
);
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('394615a9-df71-4f98-9de4-4e543ac6f6b3', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'e51449ed7fccebf02daed57c89d4e7ef12e98a8ad4101cb2a883ed6a07d00e28', 'ee507392-22b6-435c-9522-6427793f7b98', '2026-01-15T08:05:23.234423+00:00', '2026-01-08T08:05:23.237553+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('e0cfecc7-d872-43f8-90f3-e54bb72b8be4', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '38ad3d6bb2f54cd6ce92eaed382c172eaa65cee17c26ea12e691db407fd8daa0', 'a5b09968-cfcd-4c11-be18-245afec050fe', '2026-01-15T09:30:10.546777+00:00', '2026-01-08T09:30:10.547426+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('b1cda5bc-9a25-4ae4-b675-c9e3bfd04df9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '63a745df6b333cf6b4c9b2711c4447047a4fa22abed6f39016c2a76c38a4bbe3', '4b4a111a-178a-4093-a692-5981488577f4', '2026-01-15T10:16:26.167143+00:00', '2026-01-08T10:16:26.170234+00:00', '2026-01-08T13:16:37.317542+00:00', '96d81f78-3abb-4064-b4f7-f0ece8b61734', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('e01c49ab-7c53-4dad-9830-6569209deec2', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '8736e061d4f82a6b68083ea70a0837e900cec6d87707e4cea4f9701fb8569657', '4b4a111a-178a-4093-a692-5981488577f4', '2026-01-15T13:16:37.578199+00:00', '2026-01-08T13:16:37.578857+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('96d81f78-3abb-4064-b4f7-f0ece8b61734', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'ffba956023ed5486c0a38ab34256827c76a47d4dc08ed1f77f77e9eafbe322af', '4b4a111a-178a-4093-a692-5981488577f4', '2026-01-15T13:16:37.278896+00:00', '2026-01-08T13:16:37.281874+00:00', '2026-01-08T13:16:37.590472+00:00', 'e01c49ab-7c53-4dad-9830-6569209deec2', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f793b6a3-4e51-4ee6-ba3d-def342da9fd0', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'ebc10b23946c29fdc2738883b4fd79debdac11a6dc8c1e9c404e14164e7334bb', '60dc81e9-2f9f-4513-b9d6-c5c3b6178d1b', '2026-01-15T13:17:13.867900+00:00', '2026-01-08T13:17:13.868583+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('d7b0e412-541e-44d5-ba31-616e0865edc7', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'b70f37d31d5d91686b5086ba533127bea6e06d925c340e47782f1ef8cf2e082f', '264779e1-9d49-4266-a7d3-45bb68440cdd', '2026-01-16T06:48:28.623982+00:00', '2026-01-09T06:48:28.624652+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('9d6bd0f0-b907-4393-8793-78b980955bc9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '8ba9d5bdf42b9552db8e9bba4e5e38a6f2e54f2785a93a5743c9afc50770e738', '264779e1-9d49-4266-a7d3-45bb68440cdd', '2026-01-15T14:34:22.630846+00:00', '2026-01-08T14:34:22.634119+00:00', '2026-01-09T06:48:28.676990+00:00', 'd7b0e412-541e-44d5-ba31-616e0865edc7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4c3948a0-6086-4647-862f-c6bc75f7a0bd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'ddcee8ea7c59a35aa4c35c8493d2f3e8161677fab7b39f98227652c1932a7624', 'e607e7cc-fae4-4292-9b79-9baeb7a59125', '2026-01-16T11:01:35.729161+00:00', '2026-01-09T11:01:35.731269+00:00', NULL, NULL, 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a6e00eaf-c2de-45ad-af8e-e5fc9c0f28aa', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '98c1e0e67bfa42b98d18ebe20a1d58c0461afa3cb6bbc7a23549b2379c800d1e', '4ad72114-759a-42a5-8357-976eebbd2d3d', '2026-01-16T11:01:59.285643+00:00', '2026-01-09T11:01:59.286231+00:00', NULL, NULL, 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('b1f4525c-7760-49d8-a282-62d1f1eb29de', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'd7c09310e266b7290928992afe43367706daebed43f74f8e4c97492e1004cfe4', '6a391fca-49d6-4eb6-a380-a0c559631dde', '2026-01-15T18:28:43.085410+00:00', '2026-01-08T18:28:43.086558+00:00', '2026-01-09T11:21:37.265983+00:00', '39a7838a-25df-455a-90b6-2a38e01d6399', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('11fa2bb1-0e12-4de5-a03c-5d8c2d938a09', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '5f0599d466c01fdde3898f6398d8a4467bb62fba3cd941260a978ce97ca97ee2', 'f6125580-c9a3-4caf-b323-626ae3c48e49', '2026-01-16T11:56:29.685224+00:00', '2026-01-09T11:56:29.687083+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('86439eda-58a4-4cf3-96be-6eb28fa6332b', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '21ab7412e9cade7d2ae18f1ecd813b27ae34ff55bc2904d9f85a528936b178e4', 'f6125580-c9a3-4caf-b323-626ae3c48e49', '2026-01-16T09:43:37.411777+00:00', '2026-01-09T09:43:37.414341+00:00', '2026-01-09T11:56:29.704540+00:00', '11fa2bb1-0e12-4de5-a03c-5d8c2d938a09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('79578f00-cb08-468e-8060-4533e1dafca6', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '08f852c995e77e12589688dc0ebc4cb9cb8e00d80fdce80445ff7abb65a934f1', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T11:56:42.661561+00:00', '2026-01-09T11:56:42.662232+00:00', '2026-01-09T12:12:36.875707+00:00', '2b7b2433-094b-4d2b-a85b-ed40205794ba', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2b7b2433-094b-4d2b-a85b-ed40205794ba', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'eb7e486986504fa07fe074d999259ba5ba0479e88c9678f19e6acbd046ca4ff8', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T12:12:36.855591+00:00', '2026-01-09T12:12:36.857714+00:00', '2026-01-09T12:28:21.464795+00:00', '5e83e944-7dcc-4118-a7a2-1095b4bae830', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('5e83e944-7dcc-4118-a7a2-1095b4bae830', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '5cd21af28591612b0776abb705ce1c1e3b78355fdc0d5ed1a9a16fef1a2b5f50', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T12:28:21.445620+00:00', '2026-01-09T12:28:21.447730+00:00', '2026-01-09T13:30:06.482494+00:00', '14000b92-6e21-4f17-a298-1a9a037b62dd', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('14000b92-6e21-4f17-a298-1a9a037b62dd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '75fdfa1689d9deef0a6c54e2a11bc1b3860c6af796073859524ac34aebbce2de', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T13:30:06.438118+00:00', '2026-01-09T13:30:06.439999+00:00', '2026-01-09T13:45:09.633889+00:00', 'f51cd26c-e0ce-431e-a1ab-7c26c2ff1bc4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f51cd26c-e0ce-431e-a1ab-7c26c2ff1bc4', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'b69e76b9bac463aaf997cd2a6a31ff00a0e9b10ec1d3d752a961c32b0ccadaed', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T13:45:09.609807+00:00', '2026-01-09T13:45:09.612488+00:00', '2026-01-09T13:45:10.075125+00:00', '2c799b0f-46a4-4db9-911b-f958e5e51ab2', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2c799b0f-46a4-4db9-911b-f958e5e51ab2', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '25e8a6532b446eb16a4385b66a43d9ee8b3be04576caa9c98f4ef5f21e8d27bf', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T13:45:10.044080+00:00', '2026-01-09T13:45:10.044948+00:00', '2026-01-09T15:18:34.106477+00:00', '79e85c1d-a0db-4514-a9ff-29ccbc755913', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('79e85c1d-a0db-4514-a9ff-29ccbc755913', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '9123031b7b9c5015fa52d2e95c67f99afc57d4a465ea14ec90dff3c14a1fc80e', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T15:18:34.062360+00:00', '2026-01-09T15:18:34.064766+00:00', '2026-01-09T15:34:07.905946+00:00', '54ad472d-2302-4f0a-8762-5d4c250eb104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('755f6952-56e6-426b-b5a3-0cea754ded06', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '2d47214f1d98bd719b4f9e50c2cfa51fbdd97e4ef6ae215e042f3bee285b4b6e', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T16:16:57.481481+00:00', '2026-01-09T16:16:57.482169+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('54ad472d-2302-4f0a-8762-5d4c250eb104', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '935a55f543edcb19dc095a6eace4ccbe353692617ee0f3ef2203964db30a2ff3', '9e74ee4f-7065-4b1b-a0de-a2665ac8fa54', '2026-01-16T15:34:07.879159+00:00', '2026-01-09T15:34:07.879713+00:00', '2026-01-09T16:16:57.515619+00:00', '755f6952-56e6-426b-b5a3-0cea754ded06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('99568e3a-e8ef-466b-8ca5-c4db4d900079', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'd3a478f30b65584ab25bf74ba0d749453ab7f93d025d024af345854cf169cb88', '66cabbd3-3a9b-4cdf-b21f-9eca1387b364', '2026-01-16T17:36:33.564159+00:00', '2026-01-09T17:36:33.564641+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('bf4418c5-2f11-4f97-965c-f25b6c9775d3', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'cc6e8c44623d472a3291529835273a6cc23db90d1cf3f42609b46a79b5a98993', 'b2570ca4-e32a-406a-990a-68d2a9fe927a', '2026-01-17T05:56:21.673427+00:00', '2026-01-10T05:56:21.674008+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f1fca5c5-5afa-41c2-88ad-55bd92a7b989', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a76d388e3ef3ae1df7d6aaca1d46f6212ffc7eede50e00b63ea8fe37c2373173', '985d6ff4-c09c-41d8-a079-e52920f40cb1', '2026-01-17T10:49:06.556968+00:00', '2026-01-10T10:49:06.557516+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('94bfb79c-5a47-4d17-80d2-272a985fa08e', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '962b9e34e1537a4b51b64bba82e2bd4c2d2ee1fe5aeb98470ec470bf6c3d8751', 'f1d0485a-a424-4f0f-8191-d94ce86ab352', '2026-01-17T10:56:31.627719+00:00', '2026-01-10T10:56:31.630850+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('b9d5c0a6-0f75-4c36-a798-37fd1f6bc12f', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '22ec65c6515487b7889e1e0cee70986aded2568e6f3739809ce1068dfdc25942', 'c11ab3bc-ad88-4ee7-8a9e-d73367999af2', '2026-01-17T10:58:28.582571+00:00', '2026-01-10T10:58:28.583077+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3330924f-15a6-427c-845f-76f1ba3b4f78', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '9497604a8481521f23f7c247f6763bd789f8b55db785ab74ae8ea19889bec252', '41e24765-0cae-470c-ab0c-029649999014', '2026-01-17T11:38:43.821845+00:00', '2026-01-10T11:38:43.824328+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('9d2d4377-2803-44a7-a193-b7adb36829de', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '8313f9cd199487da379f1935e1dde93155620e744ddb4891cd26156f676f1e4b', '41e24765-0cae-470c-ab0c-029649999014', '2026-01-17T11:12:40.561618+00:00', '2026-01-10T11:12:40.564169+00:00', '2026-01-10T11:38:43.847198+00:00', '3330924f-15a6-427c-845f-76f1ba3b4f78', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('ea3d6731-9495-46a9-b0a5-556268c2bba6', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'cee4615b4eaa2d14c6973053adf414f2098a954253ae324c2caccdebe733fd3e', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T11:38:57.685533+00:00', '2026-01-10T11:38:57.686097+00:00', '2026-01-10T12:38:03.137066+00:00', '7da808b6-9e0d-4af4-876a-9aca05ef6452', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7da808b6-9e0d-4af4-876a-9aca05ef6452', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '33aa94bf153590fd3ed0a0e6db952af5030fb54ff41ae96921e2cd58b4fe0ff6', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T12:38:03.096942+00:00', '2026-01-10T12:38:03.097473+00:00', '2026-01-10T14:06:20.278661+00:00', '09b64ce4-bcc2-495a-b966-0adbd41071bd', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('09b64ce4-bcc2-495a-b966-0adbd41071bd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'f3e9e172ff4fb1bc9e9f0b26c887e0a6d3d3b0640a0f8e46db2ef65dd3ee58fb', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T14:06:20.241000+00:00', '2026-01-10T14:06:20.241532+00:00', '2026-01-10T14:43:32.497949+00:00', '6fcc5b21-c362-4348-a4f4-42a47370ee86', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('6fcc5b21-c362-4348-a4f4-42a47370ee86', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a69d9d791659547d9c1de2bc4b80cfd46c3641eb0552f36ac5e77d2d0525eec8', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T14:43:32.436944+00:00', '2026-01-10T14:43:32.442877+00:00', '2026-01-10T14:59:24.738758+00:00', 'f3851a2e-9da1-4d03-ac91-3ca008db1caa', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f3851a2e-9da1-4d03-ac91-3ca008db1caa', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'e988b38cb7f9a40dd65e0b35a2b7ae566e635bddc264fa81e61dc930e622bfdb', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T14:59:24.716263+00:00', '2026-01-10T14:59:24.716971+00:00', '2026-01-10T15:32:07.287444+00:00', '2a787e50-6bf0-4e69-8cd5-9b8b7c7550c2', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2a787e50-6bf0-4e69-8cd5-9b8b7c7550c2', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'e216b0ccd61887b57afa9ab4c949b459beed7cee5a0d45b4b4aca5f6be5df0b8', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T15:32:07.251547+00:00', '2026-01-10T15:32:07.253099+00:00', '2026-01-10T15:50:57.361942+00:00', '2de5d83c-142a-402d-be4b-a5825c907ad1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('68cec823-4206-492e-85f1-db96abd4e1c7', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'dd5f2826594326a4014d8814a3014b07d62cb1400054478ad4f01c8a722002b1', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T17:40:44.890113+00:00', '2026-01-10T17:40:44.890628+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2de5d83c-142a-402d-be4b-a5825c907ad1', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'c0310584fee7d04ae143ab61b40f23e91c581624383e0d3838560036d254b15e', 'ecae7269-795e-4a0c-9ea1-deb87d194950', '2026-01-17T15:50:57.329336+00:00', '2026-01-10T15:50:57.330000+00:00', '2026-01-10T17:40:44.934717+00:00', '68cec823-4206-492e-85f1-db96abd4e1c7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('5bd71534-f0a7-4344-8871-482d6298a1df', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '6a8e9d05bf7afb2a15c9492856e5b663407b5b61d293edfa953dfa9c230c83d6', '8793c3e9-cda5-43a1-a379-21a35b6f17eb', '2026-01-18T05:37:51.421968+00:00', '2026-01-11T05:37:51.425337+00:00', '2026-01-11T06:00:20.550303+00:00', '3f1fea47-0c72-4c4f-8c53-1d68b3b861b9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('39a7838a-25df-455a-90b6-2a38e01d6399', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '319ca047e69d2b9e0bd1e01d08af84d72b76e5a1440b47bac8076b226fec8fc4', '6a391fca-49d6-4eb6-a380-a0c559631dde', '2026-01-16T11:21:37.205554+00:00', '2026-01-09T11:21:37.206096+00:00', '2026-01-11T06:48:33.357905+00:00', 'cdcb4ac5-4e95-49e8-95d1-af82bffd3551', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('cdcb4ac5-4e95-49e8-95d1-af82bffd3551', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a76958fdc7a79b06784849ac90559ce2272ccdf887837c7a36ebb2cc55a8e0f5', '6a391fca-49d6-4eb6-a380-a0c559631dde', '2026-01-18T06:48:33.311879+00:00', '2026-01-11T06:48:33.314325+00:00', '2026-01-11T06:48:48.801134+00:00', NULL, 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('bdb93501-4d63-47ee-875b-f8199a641048', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'c79461ffe4df9fd3db7bcdc8a9b4fd3b66dfb07351fa0d474f86c9b03ecbe98f', '1299a659-04c7-4488-8274-652d2d632bfa', '2026-01-18T06:49:00.965922+00:00', '2026-01-11T06:49:00.966396+00:00', NULL, NULL, 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('1bd608a1-7315-43e4-ab07-574820581bb2', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a17e7ed4dc5eb96425990f74b3df6ded4e247eb861aaa2041833bc342d2a9137', '8793c3e9-cda5-43a1-a379-21a35b6f17eb', '2026-01-18T06:50:03.092926+00:00', '2026-01-11T06:50:03.093384+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3f1fea47-0c72-4c4f-8c53-1d68b3b861b9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'e82edcddb438a691e2a464e01a89800f16fe61678b9b35e5993145d7adc03e28', '8793c3e9-cda5-43a1-a379-21a35b6f17eb', '2026-01-18T06:00:20.495350+00:00', '2026-01-11T06:00:20.496093+00:00', '2026-01-11T06:50:03.104841+00:00', '1bd608a1-7315-43e4-ab07-574820581bb2', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('78a9eaaf-4e01-4366-9e06-146eee52df7d', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '752c90ff824dc1590994586f8cd9b60b3106aa1fa574e27544d9dcf918c2b70b', 'b8fd087a-413b-43df-bee7-95448485d637', '2026-01-18T07:51:24.729282+00:00', '2026-01-11T07:51:24.729967+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('94e78b0a-8dbe-4dd3-8cf5-1d64f25d4bed', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '8340b141dd3a0ab1b2e5a902a42c98712be6e0fe54ba8543f8412cb384cb998b', '0c6a76c7-b4c6-4d9c-b673-d65685daaf32', '2026-01-18T08:18:48.067022+00:00', '2026-01-11T08:18:48.070046+00:00', '2026-01-11T14:04:23.092054+00:00', '31a9f2e7-5931-4f72-abb9-acfe468b3db9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4fe2331a-abd0-4ffb-b418-2497a23f8a90', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a98eb7a723de40b8a37d665e50725cd5fc54f20dc9a62fcdbf9835f59b67939b', '0c6a76c7-b4c6-4d9c-b673-d65685daaf32', '2026-01-18T14:34:12.566558+00:00', '2026-01-11T14:34:12.567165+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.7');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('31a9f2e7-5931-4f72-abb9-acfe468b3db9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '9322e0cc7edebce55dd10992d5bc3e065e309481d40c59a719d2d35298c58d43', '0c6a76c7-b4c6-4d9c-b673-d65685daaf32', '2026-01-18T14:04:23.046276+00:00', '2026-01-11T14:04:23.046893+00:00', '2026-01-11T14:34:12.596099+00:00', '4fe2331a-abd0-4ffb-b418-2497a23f8a90', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.7');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('206310f4-35de-4cb5-a3dd-75f737729d2e', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'e320e344b5586a9ecfe7ea1d6cbba92416e58c16c9f4bc255401e947af1e083a', 'a5f87293-40dd-4367-baab-a0e13e0ee4da', '2026-01-19T02:57:22.165283+00:00', '2026-01-12T02:57:22.166135+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7863890b-4ea1-4397-a5ec-d710b6072050', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '5ea4e5364e8fd585e1fcc92d15c4e10711ecfdf9d524ce4dc25720bf4dbad202', '5995cd41-f6bf-4dea-b2a2-9ac2c0cc1e33', '2026-01-19T03:15:40.943844+00:00', '2026-01-12T03:15:40.946884+00:00', '2026-01-12T03:41:26.140078+00:00', '89cf5e46-ad24-4876-9738-a56375e584d8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('89cf5e46-ad24-4876-9738-a56375e584d8', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '0477640b3c6444c80db90d3d850cc9dfdc0a6390b9f4287127faa4783f65de82', '5995cd41-f6bf-4dea-b2a2-9ac2c0cc1e33', '2026-01-19T03:41:26.101765+00:00', '2026-01-12T03:41:26.103642+00:00', '2026-01-12T03:59:39.835615+00:00', '880b2d10-a7db-4ae7-b688-197e074ccd92', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('880b2d10-a7db-4ae7-b688-197e074ccd92', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '498f07587a1a7ace7c4e2300d2f9b385af14917acbd19ca71c7110770da53b8b', '5995cd41-f6bf-4dea-b2a2-9ac2c0cc1e33', '2026-01-19T03:59:39.790228+00:00', '2026-01-12T03:59:39.791082+00:00', '2026-01-12T04:15:09.610606+00:00', '8366f061-624a-47b7-9994-ca1a30ec358d', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4889b0c1-64c9-4131-b46e-7d1d23c522a9', 'c79ff13b-1fea-4d24-a215-a97da1d2444f', '62644a78-bc22-4833-b032-d8f080beb3be', '8241915a1c448a23abeb913f6c61c2ab628915e73001533ad684a7cccedc7b5e', '8c3e36ea-517a-4d60-8f04-859a2942e290', '2026-01-19T10:38:21.423333+00:00', '2026-01-12T10:38:21.423839+00:00', NULL, NULL, 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7f3bf01a-aecf-47c1-9f46-fe1df43a3e91', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '6346b6665c50db53dead69012d119568788f5b5c90f912d5ae05b3505da3cc6e', '5995cd41-f6bf-4dea-b2a2-9ac2c0cc1e33', '2026-01-19T13:41:10.908974+00:00', '2026-01-12T13:41:10.909709+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.8');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('8366f061-624a-47b7-9994-ca1a30ec358d', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'b6327f4f849a3b58fa4ca2b79ee343c47992c523f8dbef3a8bd0a2cfe54d2084', '5995cd41-f6bf-4dea-b2a2-9ac2c0cc1e33', '2026-01-19T04:15:09.569716+00:00', '2026-01-12T04:15:09.570567+00:00', '2026-01-12T13:41:10.954255+00:00', '7f3bf01a-aecf-47c1-9f46-fe1df43a3e91', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('da0d051d-8099-440a-8f17-2662ed2fc380', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '44ce29af1d19ff91d5313a2f009de127318c85d669ee4b458e82d7296dfe23f3', '2b238a9c-accf-4ac7-ae7b-b123a0339ee6', '2026-01-19T13:46:57.427223+00:00', '2026-01-12T13:46:57.427849+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('1317559f-7db0-4b54-b091-466463814ef9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'fa0fd56b0366dedf9089c82bb2d6be9af9888167da6298fa1fda3e4485989518', 'aea3e584-ba32-4dfc-8c0d-d76400d6c753', '2026-01-19T13:58:05.218778+00:00', '2026-01-12T13:58:05.221397+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f4bd9ac8-4dc1-441d-9351-4e24e076dcad', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '064ff31187ed860b0bbf39331b0243ea816df1255b275c144a549c82868d291a', 'f7e0965e-b6a3-42fd-8eca-316379ae1a81', '2026-01-19T14:14:19.721475+00:00', '2026-01-12T14:14:19.722054+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('54124e46-433b-418f-94ae-fc72c4529ffc', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '9686e5fa6d4bf99941634bda6e0f9ef8873d586609ee577547c9b3ee14aacecc', '7f4428be-7f3f-4a9b-af07-be5fd1b40c4b', '2026-01-19T14:53:16.140022+00:00', '2026-01-12T14:53:16.140488+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('07435ac0-3fa0-4266-bd0a-f88c190bc92a', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '0154a3823257d8f35013b3f6ace8b2639d088ba2d8e614c91417d31ee62fbdb2', '7f4428be-7f3f-4a9b-af07-be5fd1b40c4b', '2026-01-19T14:27:55.995388+00:00', '2026-01-12T14:27:55.997439+00:00', '2026-01-12T14:53:16.150476+00:00', '54124e46-433b-418f-94ae-fc72c4529ffc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('5587bd12-428f-49e0-be21-fe1558ee1062', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '154db374908cb0dc87995ed3d2cadf08ec4b81af93f0f51da28de66c8d3ea1ec', '936d1777-f45c-49f0-b874-8c0e5f16b18f', '2026-01-19T15:01:45.699861+00:00', '2026-01-12T15:01:45.700343+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('175c1da5-6fff-405c-8abe-044628ad5179', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'b425bfcae3fa30a179447e980a8f98666b20c3e01ee4ecde9c87f7351348e8f1', '936d1777-f45c-49f0-b874-8c0e5f16b18f', '2026-01-19T14:45:29.487937+00:00', '2026-01-12T14:45:29.488447+00:00', '2026-01-12T15:01:45.721140+00:00', '5587bd12-428f-49e0-be21-fe1558ee1062', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a0ebea5c-c67c-4f7c-8d65-86d015272344', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'c12663dc5d302ab871ee167fbb10bdd0ee4bea02c5bad0ad9f1405a5ac1bc051', '065af56f-14b8-4384-ad71-2e88eb26fb2d', '2026-01-20T01:20:41.230596+00:00', '2026-01-13T01:20:41.233116+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2fe3f043-7966-4bde-8310-ed52ee8c9d71', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', 'b4e9ea89745610c7ad8a42e755bf00b853bdffb4e6cba73b1168ad4a7acdf0d1', 'a2ebc7f3-0572-4c64-979e-5d39904f8ba4', '2026-01-20T01:36:13.521166+00:00', '2026-01-13T01:36:13.525065+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4a90f8a0-06c9-4674-8b0b-ef7a5b063160', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '9d17a9d3cb137936a7a97512dc065ff7660475ba44aa84384bde9f8535fffa6d', '2be2c410-cbcd-4931-93e0-5f552b476247', '2026-01-20T03:30:09.155765+00:00', '2026-01-13T03:30:09.159006+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('843736f3-b728-4a0d-9e8f-755417ca2035', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '2e561eeca4adb22ed4829fe061c0a86fd120893ece18708e32713d881aeac67c', 'fdfe6afb-5d4e-4837-8799-9e5527384f88', '2026-01-20T03:56:07.296484+00:00', '2026-01-13T03:56:07.297064+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('46578efc-361f-43bc-b69b-60d47d433a08', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '2c674280987e19ee608da1ceff3035f85616f58237ab2eefc5c9e6e2b9d1d3ab', 'b1835e03-0fd5-41ec-aa7f-855044d0fe6a', '2026-01-20T06:54:30.358775+00:00', '2026-01-13T06:54:30.361313+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('58c02263-5237-4c2d-873b-e25244ea8bb1', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '834971f58709ae769ab5e4887d8e5c4c38857d01251767618a16e562604a5203', 'b1835e03-0fd5-41ec-aa7f-855044d0fe6a', '2026-01-20T06:14:46.376747+00:00', '2026-01-13T06:14:46.379189+00:00', '2026-01-13T06:54:30.410222+00:00', '46578efc-361f-43bc-b69b-60d47d433a08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4898d3c5-2a89-4129-8a47-3ae5dec2a2e7', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '4c404681374f92d410835511024023c9fb7d15941e25deaab109ccb05f2c915c', 'b4569e5b-0616-49e6-ab59-23702a0e6d55', '2026-01-20T07:04:14.691727+00:00', '2026-01-13T07:04:14.694573+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('d334b47b-649d-4b81-9c35-98e0f337b35c', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '7bd6b09b1a63d2adfef2cfc137d1834da69c6ea0ab1a6dce88cf4cf408b61fd6', '2955edba-1c70-46ae-a6aa-319cf01febe2', '2026-01-20T07:23:01.229572+00:00', '2026-01-13T07:23:01.232277+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('462168ec-607a-4b89-92ff-02cc8fe3f7ad', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '408d754793600725ed41d8733b9ad751d395cf0397d234cfc35c9dfa674abaa6', '6fc8bb1b-33c9-4de9-ab8a-410c92e903e8', '2026-01-20T07:23:21.472456+00:00', '2026-01-13T07:23:21.473059+00:00', '2026-01-13T08:00:18.154454+00:00', '9b0994bf-3573-49cd-84c4-355a84e423bf', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('afd8b92b-a28d-470b-a96f-94043165f013', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a64ba5dcc946c17dd4e888ae07b6d7c825a5175ed4c7a100e6b7299255de5ff7', '6fc8bb1b-33c9-4de9-ab8a-410c92e903e8', '2026-01-20T08:18:23.235543+00:00', '2026-01-13T08:18:23.240180+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('9b0994bf-3573-49cd-84c4-355a84e423bf', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'f12f3225d704be7f19fe254323d0f43d183b1e75b5e89d92fb7af4dc690a8b0e', '6fc8bb1b-33c9-4de9-ab8a-410c92e903e8', '2026-01-20T08:00:18.121078+00:00', '2026-01-13T08:00:18.125007+00:00', '2026-01-13T08:18:23.277775+00:00', 'afd8b92b-a28d-470b-a96f-94043165f013', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7d69fa50-cc9a-4a55-8762-eba9418f8ee0', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '76e87236a0ec38b7c2a8514f41b055b063ce4f52e0ffb80d7e3a2e5e1d054881', 'cac5655e-6e4b-422f-b1ac-eddaf16388b8', '2026-01-21T01:24:38.903869+00:00', '2026-01-14T01:24:38.905831+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('0c5eb7a4-b232-4489-9cc9-6cde9dd224c9', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '4cec3a7919f15be6e051fcd2e6962c617b03f33d08c15e5fda03336ae6abdbfb', '4689547f-8a78-48be-88b9-a6d9358dcdab', '2026-01-21T01:32:00.727468+00:00', '2026-01-14T01:32:00.727989+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('5e9088f9-3345-4c35-9910-658340b294f7', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', 'f268c3d82ea55565036a3b85a9e0a05fdf743b19b6498f473cc9e1249abd1f4b', 'e707c5a8-d789-47e0-975e-c6e9b2924590', '2026-01-21T01:49:16.591599+00:00', '2026-01-14T01:49:16.594093+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7b0d92eb-64eb-4911-a566-f662d63c8d3a', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a1cea71d5c2bd1e8e349755ebf5fc5ca8eb3de54114917b394df8b6b522612b2', '952064be-fce3-4c88-96d6-9eb0d735aa89', '2026-01-21T02:21:51.239666+00:00', '2026-01-14T02:21:51.240619+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('57697201-964b-4b2b-8cf5-e9280c2ee730', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '0972b4864b1560a714fde2d76eb18572576e86bd3dd086b8d03c1dd18c8fb4f3', 'fe50311a-27ab-4606-a5fd-8ec3a745b762', '2026-01-21T02:22:16.636557+00:00', '2026-01-14T02:22:16.637340+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('b9bc0a0c-5f40-41ba-a3ef-ab2d0bbf07ad', '5c00b9a2-e13f-4374-904d-eedb90cdbb10', '62644a78-bc22-4833-b032-d8f080beb3be', '1416b2c8c5aee5962d37aa4ed50b6cf470bd036252b7d030d487b7c30f760ae4', 'cd97766e-716b-4e2e-b231-5756797e88eb', '2026-01-21T06:29:52.080627+00:00', '2026-01-14T06:29:52.081146+00:00', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('eb1cca6b-2b6e-4fd9-8e03-74cbc3278fd3', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '84cf7bd1d0d04365861cad8158aa1f0eb14fe2b9a44a2d9ba4835c5cdf947b11', '11918eaf-34a9-43b6-961d-424298f5a0a3', '2026-01-21T13:56:36.343191+00:00', '2026-01-14T13:56:36.346697+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3029cf72-229e-4d72-9ec8-dc31b0ec85ce', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', 'a977df287f37f6d28f6f636d6abdd5a5a3a34bb2a7ec572cf8642e85c3680a45', '4aaf3d43-0085-4b7e-aa0d-50d103c8f0df', '2026-01-21T13:59:27.890708+00:00', '2026-01-14T13:59:27.891706+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7ad05a97-5b5b-408c-ba67-0d77cf49ff25', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '5661fc2c6374b5baffac4a87a841939253b4edc386d604f8e03ff34e2ed09908', 'd56c958e-a584-480e-bfe7-0c827d931f75', '2026-01-21T14:53:43.247679+00:00', '2026-01-14T14:53:43.248850+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('acaec374-53aa-4651-80b0-6e7ff7d1416b', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '7c489d436c44329b8cc5910031117cdb4ac401c34baa57cdeca020f82ae3dcbc', 'd56c958e-a584-480e-bfe7-0c827d931f75', '2026-01-21T14:33:08.713469+00:00', '2026-01-14T14:33:08.714229+00:00', '2026-01-14T14:53:43.272574+00:00', '7ad05a97-5b5b-408c-ba67-0d77cf49ff25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('06a433d4-7e3d-4dc2-a5b6-238c7c50e9b0', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '31bbc194ea4f6dee9619c4c960e1fc0df932a2dc9d999303d70244b4aa9d8d85', '0aa90656-ddba-40e3-a18d-41dc040b4acb', '2026-01-22T02:08:24.736885+00:00', '2026-01-15T02:08:24.737342+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.10');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('659a5cc8-61d4-41f8-9f72-ca96cce307a3', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '0c4d672bd8b0a9454b15b9ea4d27b4a3325a63dd20f1e4b6c29f925f06d16a95', '4fee4215-e0ee-411a-a98d-916463eaa061', '2026-01-22T02:09:09.279201+00:00', '2026-01-15T02:09:09.279640+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.10');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('ac893914-21db-41f5-bf50-1f78a7827c98', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '607378eceba8037550191acecf87dc511a85fe2bd08400dba2915eaa953900ae', '293020da-c0ab-4bab-a5fa-c9566d527089', '2026-01-22T02:45:46.156637+00:00', '2026-01-15T02:45:46.157105+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('9425b338-b3ae-48f0-a9ee-57a797bc0efd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '2c9d268518482fea0a1a0cb7096507b56e9599695f632847e0d40bae033e8e86', '7e09d512-e45c-4c3d-9694-d6495f2b444a', '2026-01-22T07:47:59.759825+00:00', '2026-01-15T07:47:59.760408+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7090cf53-eced-4bc1-bbc1-31a8ac474dc2', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '2599c3d40c29404730cd616f25f97095b8866697a63026a976e6e9435fd22611', 'ac848f87-b9fe-44b7-b1cf-a58abf495995', '2026-01-22T13:07:25.913359+00:00', '2026-01-15T13:07:25.915843+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('11cb2179-eccd-4f77-bb3f-d2e15e6b82d0', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'c35204a146be0f41e594fbb68d568108d691bc7e6848abd2ce406e2c41646041', '108c7a82-eb20-4c64-a621-4a7d38c82185', '2026-01-22T13:27:55.943486+00:00', '2026-01-15T13:27:55.946522+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3e2627cc-e284-4a55-879a-c8ead7a804b3', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'be1e7c75a93575ef99f35b5e5b65d5311dbec461b3dc63e160c93afcac8b8d3e', 'd2d6d556-80fa-423c-8082-c080323c5102', '2026-01-22T14:09:53.073361+00:00', '2026-01-15T14:09:53.073837+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('67d7ee3e-db63-4b92-b64d-f6c51af1807b', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '1887f7daf9afe6405574c19c724067912e596fb22f8a3d4f562bfd515063074f', 'af98dadb-dd0a-4349-8b68-29b8ac5b7b6c', '2026-01-22T14:52:34.964663+00:00', '2026-01-15T14:52:34.965691+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('ab959c88-df14-44f3-b28c-480fe652b5c4', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a286e3e787a646fb4d8bc7da55d84a3f87248125711ce9658e14abc629e9e17c', 'af98dadb-dd0a-4349-8b68-29b8ac5b7b6c', '2026-01-22T14:34:45.266986+00:00', '2026-01-15T14:34:45.267848+00:00', '2026-01-15T14:52:35.078020+00:00', '67d7ee3e-db63-4b92-b64d-f6c51af1807b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('221285e4-0420-4171-a63a-25ec20068e61', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '5160a7fd2648a45663b6a51f1598a1c5ade0c08d9d2aea0040140f7bd3be961e', 'f12fb26b-d5b0-4d8b-b9aa-3f837f647abf', '2026-01-23T02:55:48.822907+00:00', '2026-01-16T02:55:48.825771+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('ee84c04e-f520-42d8-94b1-f5b8468186dd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'fa01d6a4e8a29885830b8dea8521a5323fd33d527727b1bc79831985d0322267', 'bf236330-1bfb-4fb8-bad8-6e2ab5b5ffbb', '2026-01-23T03:09:52.555695+00:00', '2026-01-16T03:09:52.556381+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('c530ae07-86cb-4aa9-80da-9e8dfe2cd327', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '61577cd55a39b4b908dae7e3040d3adcb50f74055b6c5a01ada6e218517fe890', '1db5403f-8571-4db1-af2e-f82e8f11c204', '2026-01-23T04:12:11.564280+00:00', '2026-01-16T04:12:11.565186+00:00', '2026-01-16T05:39:04.804406+00:00', '23bfaeaf-92a0-4bf6-bd5d-712c17b7a155', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('23bfaeaf-92a0-4bf6-bd5d-712c17b7a155', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '396491e631df18284737ec27fd44aaf2bc6a9882ca9795c1b95951d7e42b4512', '1db5403f-8571-4db1-af2e-f82e8f11c204', '2026-01-23T05:39:04.514166+00:00', '2026-01-16T05:39:04.514854+00:00', '2026-01-16T05:39:05.325354+00:00', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7f2b2670-c313-4586-8f9e-25d45f2ac258', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '13988fd9bed0bfd20a311a693b69e322c4603a2841729ef12c2c1f254c6aba11', '0885fd68-8a57-4808-b7e0-213dc3ea75a6', '2026-01-23T05:57:33.569799+00:00', '2026-01-16T05:57:33.570663+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('971b1569-0c28-4c4e-bec0-4af61e3ba504', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'ff34cfd1ff05bcdd9ab4e1de2f94874228ff97553010dee79c31fc8f8e0c9990', 'c2484e7d-3027-4c73-b962-580701b033ad', '2026-01-23T06:34:43.215667+00:00', '2026-01-16T06:34:43.219534+00:00', '2026-01-16T07:00:55.494029+00:00', '8ab27b72-a90d-4263-95ba-07fb21340dcf', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('792afa02-781d-4f14-8af4-37c684aa39d3', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '3e34243d9ac7dbed7795c751da84ccd2a244738125073853fb418564f46cf919', 'c2484e7d-3027-4c73-b962-580701b033ad', '2026-01-23T06:19:18.218610+00:00', '2026-01-16T06:19:18.219586+00:00', '2026-01-16T06:34:43.520641+00:00', '971b1569-0c28-4c4e-bec0-4af61e3ba504', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('8ab27b72-a90d-4263-95ba-07fb21340dcf', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'ce9a24bce9f208b84647f731d7cfc5fe82ae7be4fdf8d56dd906d36514f28f7d', 'c2484e7d-3027-4c73-b962-580701b033ad', '2026-01-23T07:00:55.188189+00:00', '2026-01-16T07:00:55.191470+00:00', '2026-01-16T07:00:55.905406+00:00', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('fe72c630-2098-4e97-b89d-8aa038a84d51', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '09def455adc0d10d3712912045eb9b1a2dbe97dc0bb6dbf14abce3659ac25082', '26265025-8c03-4109-ad06-cff8182c763c', '2026-01-23T09:35:22.509947+00:00', '2026-01-16T09:35:22.510884+00:00', '2026-01-16T09:57:35.246179+00:00', '680c925b-eeae-4898-884b-7464fbc079e1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('680c925b-eeae-4898-884b-7464fbc079e1', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'b43397e9ea07a9e712bc85403f6de41d1c98d6734a5c15c969b54e01a60f2bf5', '26265025-8c03-4109-ad06-cff8182c763c', '2026-01-23T09:57:35.127228+00:00', '2026-01-16T09:57:35.128208+00:00', '2026-01-16T09:57:35.406806+00:00', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a3dce507-09fa-49f9-b402-016772ef1234', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '91dec24e4f1201a4e39e92061956debfae7103d9d35722b3086d26e37001a861', '13a54a98-f71c-4fcd-888e-1f372c528585', '2026-01-23T11:48:05.008245+00:00', '2026-01-16T11:48:05.010008+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7997d551-f082-4ac2-aa6c-cf63dfdfd58d', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'bfe18c7346006476997c29e4f78e93a42ed64a0cdfcfe841de1335f786039b7b', '8d69564d-b9bb-4c79-ac31-1acb152cde21', '2026-01-23T11:49:29.013046+00:00', '2026-01-16T11:49:29.013948+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('86cb4547-ecd5-4067-8f00-1f5c9c06c3d4', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '6f66ccb8fed4d6c256476024c12f89db22b8b17c3a6af15b5f3775937b8373ea', '92ea56da-3631-46c6-803a-349d2f91f590', '2026-01-24T07:37:35.860110+00:00', '2026-01-17T07:37:35.862036+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('f0c4b84f-3b5d-4f83-841d-7cbb4a9e8683', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '26c17081e3795bad79647eb9dcf9db4e677bbad3dd56aa8ad99a8e1c7ddda3cd', '467ef24b-3151-4cf3-b204-742348c0e588', '2026-01-24T07:54:03.047871+00:00', '2026-01-17T07:54:03.048639+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('5c1dd627-d6ce-41a4-b70c-34bf0edb4f83', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '375f9b5b866500da59859a73097e42116fb827d3208577ff66dd3200d9c336c4', 'f96c9609-fb7b-4bc0-b658-9343758825d6', '2026-01-24T07:57:11.724526+00:00', '2026-01-17T07:57:11.725030+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('ffc5ee5e-81ec-4ac5-8682-a5602165e2d9', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'a968102e15c63ab2e722b6fffdbce7aafa7784f5de9e36cff50b400b80aeea6d', '28cd6064-9af2-4c24-aee2-53085c6822e8', '2026-01-24T12:11:52.467223+00:00', '2026-01-17T12:11:52.470202+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('c6d9cb5c-ca59-4fca-beb2-a5663256ed1b', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '6550999129fea28b5be4fa7f4eb70ca84ea6885b3f31f5e588d297bdc2b811a6', '573701b4-712a-4ab7-badb-0787a1cb943a', '2026-01-24T12:13:02.764891+00:00', '2026-01-17T12:13:02.765637+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('dbf8be4c-b5f3-47ac-b8ef-b9c178bbf238', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '890fbf0d73388bfb8bf03c657374bb50c87284b39c5e7c1b653d22efa013c9c6', '8a0e9dc5-59c1-4f40-a3ed-de82d9b3d72b', '2026-01-24T12:49:38.975535+00:00', '2026-01-17T12:49:38.976114+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.4');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a9cfb3bb-a7e9-4c78-b42b-be69846e2f3e', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', 'bfee66b8458521cf1df1f32bd26f26ebd925fa91a10a2986fee4592f17b38f61', '8a0e9dc5-59c1-4f40-a3ed-de82d9b3d72b', '2026-01-24T08:42:25.697209+00:00', '2026-01-17T08:42:25.697750+00:00', '2026-01-17T12:49:39.022744+00:00', 'dbf8be4c-b5f3-47ac-b8ef-b9c178bbf238', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.5');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('cf01f191-bcfb-4621-9f21-4c12d858075d', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '35491f114cc856f7771ac02e684fdb6aa5f2fec4fc05e65243972a5a5486cc63', '728fa46e-ff5e-4d3e-81fc-0e46afebf930', '2026-01-24T12:50:14.121605+00:00', '2026-01-17T12:50:14.122173+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('8f6e7c09-89d3-4657-83f7-66f4db72d654', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '9e9409edb55c6cf304efcaedb0a86a3ffc0e721cdbd3b42c1dc72938d4b61bf2', '6b0f3ab9-0139-4551-8119-14b93ab75f80', '2026-01-24T13:03:29.562978+00:00', '2026-01-17T13:03:29.563638+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('fb15ce3c-8130-45d8-8b55-6aa4c30f7547', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '750f782b7a6288e71b42df102f58154b973ef216b8293b83d93b967900b96c6c', '4415ed44-28e4-4b9b-9d78-4bb92e108398', '2026-01-24T13:32:52.291299+00:00', '2026-01-17T13:32:52.294400+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3ff96562-82ad-46a7-aa84-50e70a013791', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'f425d9536d594aff710165bfba451b27ac803972fa90a4c92ce55dda4c0d5eb6', '0eab30c6-4193-42eb-a05b-116497d08497', '2026-01-24T13:45:29.822023+00:00', '2026-01-17T13:45:29.824649+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('2902f43a-6301-420f-8b2d-6c537df29001', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '124da3b95ca82482bba3cf506b7e1113750eb77d4c7e630d696edb3e0882ee33', '15fa438b-564f-4102-86b8-80d22549455a', '2026-01-24T13:45:37.994507+00:00', '2026-01-17T13:45:37.995537+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a2f52456-0771-4c8d-a311-cd10526fad89', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'fba81a58553ff0061c31b6fd03519f3f5f67c779bba1eeba82026a86bfa5add5', '5f63474e-4067-4008-9102-a2e7f6c6c4be', '2026-01-24T13:46:43.813722+00:00', '2026-01-17T13:46:43.814261+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4b69fd76-5f71-4483-b1a0-a96ad5b3fafd', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '6400e87eaba97af7411c30a96da6b42773fc94e309ef6a3df4fa265bf7e9c82f', '14bd120b-75e4-4972-97c1-a5cce210f2db', '2026-01-24T13:49:22.034150+00:00', '2026-01-17T13:49:22.034906+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('3eef2081-f078-4fe3-8afa-00e61982a5a7', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '3ec302b9ca6355dfc1e730a8cc4ff5164189d73b60e7ec1101241f18c8adeaf6', '80594afb-ec69-4901-b02c-3a1d2b4fb09c', '2026-01-24T13:56:42.763613+00:00', '2026-01-17T13:56:42.766032+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('4ae76ae3-0f16-49aa-ae3f-8a7fc238dfa8', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '433c060fc46da5ba01d7703f8faa93b0281940b07ebff439bb5d6d07cc640579', '9d828175-56b4-4f58-a988-33d872091c8d', '2026-01-24T13:58:22.888770+00:00', '2026-01-17T13:58:22.889403+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('7a9915a2-dd20-4c49-a9e5-e622a29b089b', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '1ea009e896206352011ad60d097897a5d9973fc786880ab9d9048049086b12eb', 'a0002f1d-b7fa-489d-beb0-b7a88e79b994', '2026-01-24T14:39:37.375917+00:00', '2026-01-17T14:39:37.378288+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('9973c25f-03d7-41a7-a571-fcc00d808fb2', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '8ef61e60944c41c8b4d404f4723af5910c45da3200912afa9faba9c62d7564b1', 'f8ac61a7-0315-45ca-8224-c70e3644cb08', '2026-01-24T14:39:45.693803+00:00', '2026-01-17T14:39:45.694324+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.2');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('94b116fb-868e-4caf-b539-158b09a436f0', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', 'fd5a416d7628719ba8e6ee686dbf93c3dbd0cd99cdad9494cd6e75f78be7465f', '297b6659-eb2e-49f2-a0e6-78e05ae6dbfe', '2026-01-24T14:40:29.386775+00:00', '2026-01-17T14:40:29.387332+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.3');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('a5b8d717-efc7-46da-a64a-d9170329e705', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '588ea1738213c7a4c35398d634ef6a34e30d42f9e149e6a747273bccdc572540', '7c3da856-a198-4336-87e9-38ac47c28f05', '2026-01-26T02:11:03.771326+00:00', '2026-01-19T02:11:03.772384+00:00', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');
INSERT INTO "public"."refresh_token" ("id", "user_id", "tenant_id", "token_hash", "family_id", "expires_at", "created_at", "revoked_at", "replaced_by_id", "device_info", "ip_address") VALUES ('780eb9e5-8b82-47bf-b35c-7b41cf834023', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'c038b2289958d528e79a88aa488f528dae2006ef058226a89f7368483c3eb60c', '7c3da856-a198-4336-87e9-38ac47c28f05', '2026-01-26T01:54:45.392217+00:00', '2026-01-19T01:54:45.393192+00:00', '2026-01-19T02:11:03.790017+00:00', 'a5b8d717-efc7-46da-a64a-d9170329e705', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '100.64.0.6');

-- Table: public.social_identity
CREATE TABLE IF NOT EXISTS "public"."social_identity" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "platform" PLATFORM NOT NULL,
    "platform_user_id" VARCHAR(255) NOT NULL,
    "facebook_user_id" VARCHAR(255),
    "platform_username" VARCHAR(255),
    "display_name" VARCHAR(255),
    "email" VARCHAR(255),
    "avatar_url" TEXT,
    "profile_data" JSONB,
    "is_active" BOOLEAN DEFAULT true NOT NULL,
    "created_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."social_identity" ("id", "tenant_id", "user_id", "platform", "platform_user_id", "facebook_user_id", "platform_username", "display_name", "email", "avatar_url", "profile_data", "is_active", "created_at", "updated_at") VALUES ('44cd55f5-438e-4d06-952c-c3eac9892b02', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', 'facebook', '1500642824495201', '1500642824495201', NULL, 'Chan Cashing', NULL, NULL, '{"id": "1500642824495201", "name": "Chan Cashing"}', True, '2026-01-05T07:33:47.974713', '2026-01-05T07:33:47.974718');

-- Table: public.subscription
CREATE TABLE IF NOT EXISTS "public"."subscription" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "user_id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "stripe_customer_id" VARCHAR(255),
    "stripe_subscription_id" VARCHAR(255),
    "tier" SUBSCRIPTIONTIER DEFAULT 'free'::subscriptiontier NOT NULL,
    "status" SUBSCRIPTIONSTATUS,
    "current_period_start" TIMESTAMP WITH TIME ZONE,
    "current_period_end" TIMESTAMP WITH TIME ZONE,
    "cancel_at_period_end" BOOLEAN DEFAULT false NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."subscription" ("id", "user_id", "tenant_id", "stripe_customer_id", "stripe_subscription_id", "tier", "status", "current_period_start", "current_period_end", "cancel_at_period_end", "created_at", "updated_at") VALUES ('f8d39cb1-ceaf-42ef-95e8-12c0247d4cf8', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, NULL, 'pro', 'active', NULL, NULL, False, '2026-01-08T08:05:27.139954+00:00', '2026-01-08T08:05:27.139962+00:00');
INSERT INTO "public"."subscription" ("id", "user_id", "tenant_id", "stripe_customer_id", "stripe_subscription_id", "tier", "status", "current_period_start", "current_period_end", "cancel_at_period_end", "created_at", "updated_at") VALUES ('52b21cdd-5cba-4759-a7fb-4427449c38c3', 'c79ff13b-1fea-4d24-a215-a97da1d2444f', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, NULL, 'pro', 'active', NULL, NULL, False, '2026-01-12T10:38:39.021835+00:00', '2026-01-12T10:38:39.021846+00:00');
INSERT INTO "public"."subscription" ("id", "user_id", "tenant_id", "stripe_customer_id", "stripe_subscription_id", "tier", "status", "current_period_start", "current_period_end", "cancel_at_period_end", "created_at", "updated_at") VALUES ('ffbdc127-61c3-4105-86aa-efcb745b1e02', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, NULL, 'pro', 'active', NULL, NULL, False, '2026-01-13T01:37:31.819042+00:00', '2026-01-13T01:37:31.819048+00:00');
INSERT INTO "public"."subscription" ("id", "user_id", "tenant_id", "stripe_customer_id", "stripe_subscription_id", "tier", "status", "current_period_start", "current_period_end", "cancel_at_period_end", "created_at", "updated_at") VALUES ('acefbc0d-55c0-4916-a411-76ae572da9b8', '5c00b9a2-e13f-4374-904d-eedb90cdbb10', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, NULL, 'pro', 'active', NULL, NULL, False, '2026-01-14T06:31:02.355366+00:00', '2026-01-14T06:31:02.355374+00:00');

-- Table: public.telegram_link_code
CREATE TABLE IF NOT EXISTS "public"."telegram_link_code" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "code" VARCHAR(32) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "used_at" TIMESTAMP WITH TIME ZONE,
    "telegram_user_id" VARCHAR(50),
    PRIMARY KEY ("id")
);
INSERT INTO "public"."telegram_link_code" ("id", "user_id", "tenant_id", "code", "created_at", "expires_at", "used_at", "telegram_user_id") VALUES ('eb584f9c-5eb1-4054-9519-5d3446cbf1a6', '51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', 'd_6lzam6OJkZvkHDKAojhjQE', '2026-01-09T09:44:21.449689+00:00', '2026-01-09T09:59:21.448461+00:00', '2026-01-09T09:44:26.852573+00:00', '1450060367');

-- Table: public.tenant
CREATE TABLE IF NOT EXISTS "public"."tenant" (
    "id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(100) NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "settings" JSON,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."tenant" ("id", "name", "slug", "is_active", "settings", "created_at", "updated_at") VALUES ('62644a78-bc22-4833-b032-d8f080beb3be', 'Default Organization', 'default', True, '{}', '2025-11-23T13:08:53.868297', '2025-11-23T13:08:53.868304');

-- Table: public.token_blacklist
CREATE TABLE IF NOT EXISTS "public"."token_blacklist" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "jti" VARCHAR(36) NOT NULL,
    "user_id" UUID NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE NOT NULL,
    "revoked_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "reason" VARCHAR(50),
    PRIMARY KEY ("id")
);
INSERT INTO "public"."token_blacklist" ("id", "jti", "user_id", "expires_at", "revoked_at", "reason") VALUES ('a7039128-323d-4fec-97d0-0741c64548c6', 'ec12862f-ad2b-4c90-a59c-3048109df21f', '51e61235-0326-4739-997e-c48fd9e44bcc', '2026-01-11T07:03:33+00:00', '2026-01-11T06:48:48.772296+00:00', 'logout');

-- Table: public.user
CREATE TABLE IF NOT EXISTS "public"."user" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "telegram_user_id" VARCHAR(50),
    "email" VARCHAR(255),
    "username" VARCHAR(100),
    "role" USERROLE NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "last_login" TIMESTAMP WITHOUT TIME ZONE,
    "created_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "updated_at" TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    "password_hash" VARCHAR(255),
    "email_verified" BOOLEAN NOT NULL,
    "profile_data" JSON,
    "telegram_username" VARCHAR(100),
    "telegram_linked_at" TIMESTAMP WITH TIME ZONE,
    "email_verified_at" TIMESTAMP WITHOUT TIME ZONE,
    PRIMARY KEY ("id")
);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('7ae4cbd3-3bea-4a85-a17f-11580eee28a9', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, 'Uypove015@gmail.com', 'Uypov', 'user', True, '2026-01-01T05:08:18.100070', '2026-01-01T05:08:06.543473', '2026-01-01T05:08:18.104381', '$2b$12$SCsCSkoWEOGzmfRIiv.xLOchDFNx3v0IuZs6Bz5jqXMrFV4W3hPtG', False, NULL, NULL, NULL, NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('2e51f78c-c8c1-4525-aaa1-ae48e637384b', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, 'test@example.com', 'testuser', 'user', True, '2026-01-05T14:54:37.039812', '2026-01-05T14:33:36.241370', '2026-01-05T14:54:37.068435', '$2b$12$oh0Gtrdi4W4nY78P3LUXkeUKJmTj5c0SJJBxbo4w9e7xp7D8gteyO', False, NULL, NULL, NULL, NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '62644a78-bc22-4833-b032-d8f080beb3be', '8140179993', 'test@gmail.com', 'test', 'user', True, '2026-01-17T14:40:29.372299', '2025-12-25T09:09:31.228524', '2026-01-17T14:40:29.377231', '$2b$12$kizoBSgPrb4wxnnncfjeF.FMhhN7YzuHsjkt/1KHhqQdAO8F047Ty', False, NULL, NULL, '2026-01-07T02:58:17.473121+00:00', NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('51e61235-0326-4739-997e-c48fd9e44bcc', '62644a78-bc22-4833-b032-d8f080beb3be', '1450060367', 'kasingchan213@gmail.com', 'kasing', 'user', True, '2026-01-19T01:54:45.344337', '2025-12-25T08:42:29.990817', '2026-01-19T01:54:45.357015', '$2b$12$vuujRt9Oql/fqTIds8vceuY4O.DSuX5C.ebeJEUUWJtA9wbh31Jrq', False, NULL, 'Chankasing', '2026-01-09T09:44:26.852573+00:00', NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('e3c96101-529d-43c6-bed1-74319e3ea619', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, 'phongnyta@gmail.com', 'Phong', 'user', True, '2026-01-01T03:54:13.423680', '2026-01-01T03:52:56.629391', '2026-01-01T03:54:13.428158', '$2b$12$p9yy7t6XvPuzlUdiWWZX0ue0PMjry.IXDHSfryDjy5hO5cgRoIFkO', False, NULL, NULL, NULL, NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('5c00b9a2-e13f-4374-904d-eedb90cdbb10', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, 'helunchao@gmail.com', 'helunchao', 'user', True, '2026-01-14T06:29:52.054054', '2026-01-14T06:29:47.869086', '2026-01-14T06:29:52.058425', '$2b$12$kZ2TLB71JYjyDhFG4IvoG.cWDPNYPPBjCkEbcQ6dmpg2E9fnimzYG', False, NULL, NULL, NULL, NULL);
INSERT INTO "public"."user" ("id", "tenant_id", "telegram_user_id", "email", "username", "role", "is_active", "last_login", "created_at", "updated_at", "password_hash", "email_verified", "profile_data", "telegram_username", "telegram_linked_at", "email_verified_at") VALUES ('c79ff13b-1fea-4d24-a215-a97da1d2444f', '62644a78-bc22-4833-b032-d8f080beb3be', NULL, 'hardjie92@gmail.com', 'jagat2026', 'user', True, '2026-01-12T10:38:21.409069', '2026-01-12T10:38:11.134235', '2026-01-12T10:38:21.413030', '$2b$12$7vwcOQYzqF8Kxl8mkSzG6OKqjot5SKUZrmvzWpyXupptNUNyZ.fgq', False, NULL, NULL, NULL, NULL);

-- Schema: invoice
CREATE SCHEMA IF NOT EXISTS "invoice";


-- Table: invoice.client_link_code
CREATE TABLE IF NOT EXISTS "invoice"."client_link_code" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "code" VARCHAR(64) NOT NULL,
    "tenant_id" UUID NOT NULL,
    "merchant_id" UUID NOT NULL,
    "customer_id" UUID NOT NULL,
    "expires_at" TIMESTAMP WITH TIME ZONE DEFAULT (now() + '7 days'::interval) NOT NULL,
    "used_at" TIMESTAMP WITH TIME ZONE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('cd40c2c8-5d71-46a9-9271-ba0ea0c96a4f', '_UDa8_uszlsmhN8BzgbaGx1YrJk8D2sRZ8BQ7Q717Sg', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', '042b8c77-d4df-48f8-ada2-198a1ca65d19', '2026-01-16T10:19:50.709236+00:00', NULL, '2026-01-09T10:19:50.709236+00:00');
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('19014e0e-5795-40fa-9eb3-8c2d017ca45b', 'qmGOoJehS7_T4Q93xgzjRXT6vS1P7xGn2MG4EHVxy5g', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', '0d57d876-b295-4386-a391-8a8e7206f7e4', '2026-01-16T10:29:19.261715+00:00', '2026-01-09T10:30:30.618937+00:00', '2026-01-09T10:29:19.261715+00:00');
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('fee2e5b9-e211-4bb5-9eca-d09b433e88b0', 'IquWhthJqOJhKGc2cd9qVN3J8Te5nGJ0ZBCuTshByr0', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', 'ba2507d4-a0fc-4125-9f3c-9108d06c0519', '2026-01-16T10:04:57.045571+00:00', '2026-01-09T11:58:24.376082+00:00', '2026-01-09T10:04:57.045571+00:00');
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('6f780769-abf8-4dde-8638-6a5104cf20ec', 'W8PoBxq6McbpZBWY5p6R1DGuphXkrOxViryRdkDeB54', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', '042b8c77-d4df-48f8-ada2-198a1ca65d19', '2026-01-22T14:19:49.691930+00:00', NULL, '2026-01-15T14:19:49.691930+00:00');
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('6936f61f-fb78-4764-b463-a9833d66a23b', 'yF4iDA0DoN-souSsmU_aGU3qMtvPMjC1BATHkK2QlBk', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', '042b8c77-d4df-48f8-ada2-198a1ca65d19', '2026-01-23T03:10:38.188405+00:00', NULL, '2026-01-16T03:10:38.188405+00:00');
INSERT INTO "invoice"."client_link_code" ("id", "code", "tenant_id", "merchant_id", "customer_id", "expires_at", "used_at", "created_at") VALUES ('883a2242-2b46-470e-adcd-67b80cb36f04', 'EfKNLJGJJtT_5v_ieo0bj65ePcQbbhMqhUzoh9jwE2M', '62644a78-bc22-4833-b032-d8f080beb3be', '51e61235-0326-4739-997e-c48fd9e44bcc', '042b8c77-d4df-48f8-ada2-198a1ca65d19', '2026-01-26T01:55:08.412422+00:00', '2026-01-19T01:55:20.830079+00:00', '2026-01-19T01:55:08.412422+00:00');

-- Table: invoice.customer
CREATE TABLE IF NOT EXISTS "invoice"."customer" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "email" VARCHAR(255),
    "phone" VARCHAR(50),
    "address" TEXT,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "merchant_id" UUID,
    "telegram_chat_id" VARCHAR(50),
    "telegram_username" VARCHAR(100),
    "telegram_linked_at" TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY ("id")
);
INSERT INTO "invoice"."customer" ("id", "tenant_id", "name", "email", "phone", "address", "meta", "created_at", "updated_at", "merchant_id", "telegram_chat_id", "telegram_username", "telegram_linked_at") VALUES ('0d57d876-b295-4386-a391-8a8e7206f7e4', '62644a78-bc22-4833-b032-d8f080beb3be', 'liza', NULL, NULL, NULL, '{}', '2026-01-09T10:29:19.226202+00:00', '2026-01-09T10:30:30.618937+00:00', '51e61235-0326-4739-997e-c48fd9e44bcc', '1688285127', 'LeoizW', '2026-01-09T10:30:30.618937+00:00');
INSERT INTO "invoice"."customer" ("id", "tenant_id", "name", "email", "phone", "address", "meta", "created_at", "updated_at", "merchant_id", "telegram_chat_id", "telegram_username", "telegram_linked_at") VALUES ('ba2507d4-a0fc-4125-9f3c-9108d06c0519', '62644a78-bc22-4833-b032-d8f080beb3be', 'liza', NULL, NULL, NULL, '{}', '2026-01-09T10:04:56.991504+00:00', '2026-01-09T11:58:24.376082+00:00', '51e61235-0326-4739-997e-c48fd9e44bcc', '1450060367', 'Chankasing', '2026-01-09T11:58:24.376082+00:00');
INSERT INTO "invoice"."customer" ("id", "tenant_id", "name", "email", "phone", "address", "meta", "created_at", "updated_at", "merchant_id", "telegram_chat_id", "telegram_username", "telegram_linked_at") VALUES ('042b8c77-d4df-48f8-ada2-198a1ca65d19', '62644a78-bc22-4833-b032-d8f080beb3be', 'fanny', NULL, NULL, NULL, '{}', '2026-01-09T10:19:50.640345+00:00', '2026-01-19T01:55:20.830079+00:00', '51e61235-0326-4739-997e-c48fd9e44bcc', '1141759837', NULL, '2026-01-19T01:55:20.830079+00:00');

-- Table: invoice.invoice
CREATE TABLE IF NOT EXISTS "invoice"."invoice" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "customer_id" UUID NOT NULL,
    "invoice_number" VARCHAR(50) NOT NULL,
    "amount" NUMERIC NOT NULL,
    "status" VARCHAR(20) DEFAULT 'pending'::character varying NOT NULL,
    "items" JSONB DEFAULT '[]'::jsonb,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "bank" VARCHAR(100),
    "expected_account" VARCHAR(100),
    "currency" VARCHAR(10) DEFAULT 'KHR'::character varying NOT NULL,
    "verification_status" VARCHAR(20) DEFAULT 'pending'::character varying NOT NULL,
    "verified_at" TIMESTAMP WITH TIME ZONE,
    "verified_by" VARCHAR(100),
    "verification_note" TEXT,
    "merchant_id" UUID,
    "recipient_name" VARCHAR(100),
    "due_date" DATE,
    PRIMARY KEY ("id")
);
INSERT INTO "invoice"."invoice" ("id", "tenant_id", "customer_id", "invoice_number", "amount", "status", "items", "meta", "created_at", "updated_at", "bank", "expected_account", "currency", "verification_status", "verified_at", "verified_by", "verification_note", "merchant_id", "recipient_name", "due_date") VALUES ('29558615-15f0-4e34-9681-6ec62865da8a', '62644a78-bc22-4833-b032-d8f080beb3be', 'ba2507d4-a0fc-4125-9f3c-9108d06c0519', 'INV-2601-00001', '7.35', 'pending', '[{"id": "21eb2570-3233-47d1-ac6c-f441a6aa649f", "total": 7.0, "quantity": 1.0, "tax_rate": 10.0, "unit_price": 7.0, "description": "bruh"}]', '{}', '2026-01-13T07:08:05.543496+00:00', '2026-01-13T07:08:05.543496+00:00', 'ABA', '086 228 226', 'USD', 'pending', NULL, NULL, NULL, '51e61235-0326-4739-997e-c48fd9e44bcc', 'CHAN K. & THOEURN T.', '2026-01-14');
INSERT INTO "invoice"."invoice" ("id", "tenant_id", "customer_id", "invoice_number", "amount", "status", "items", "meta", "created_at", "updated_at", "bank", "expected_account", "currency", "verification_status", "verified_at", "verified_by", "verification_note", "merchant_id", "recipient_name", "due_date") VALUES ('bbdcd95f-cb29-4713-8e1f-4b6f38e3d062', '62644a78-bc22-4833-b032-d8f080beb3be', 'ba2507d4-a0fc-4125-9f3c-9108d06c0519', 'INV-2601-00002', '7.00', 'pending', '[{"id": "dbe9808a-e8bf-4e68-8c64-d660c2915f4d", "total": 7.0, "quantity": 1.0, "tax_rate": 0, "unit_price": 7.0, "description": "nigka"}]', '{}', '2026-01-13T07:30:12.760445+00:00', '2026-01-13T07:30:12.760445+00:00', 'ABA Bank', '086 228 226', 'USD', 'pending', NULL, NULL, NULL, '51e61235-0326-4739-997e-c48fd9e44bcc', 'CHAN K. & THOEURN T.', '2026-01-14');
INSERT INTO "invoice"."invoice" ("id", "tenant_id", "customer_id", "invoice_number", "amount", "status", "items", "meta", "created_at", "updated_at", "bank", "expected_account", "currency", "verification_status", "verified_at", "verified_by", "verification_note", "merchant_id", "recipient_name", "due_date") VALUES ('39c8cc32-e329-4e66-a3a8-1422fbf79e01', '62644a78-bc22-4833-b032-d8f080beb3be', '042b8c77-d4df-48f8-ada2-198a1ca65d19', 'INV-2601-00003', '10.00', 'paid', '[{"id": "1018714e-1226-49db-8706-a66f647794e7", "total": 10.0, "quantity": 1.0, "tax_rate": 0, "unit_price": 10.0, "description": "nigger"}]', '{}', '2026-01-19T01:56:31.026835+00:00', '2026-01-19T01:58:12.203691+00:00', 'ABA Bank', '086 228 226', 'USD', 'verified', '2026-01-19T01:58:12.169033+00:00', 'telegram-client-ocr', 'OCR Record: mock-05e4f06a', '51e61235-0326-4739-997e-c48fd9e44bcc', 'CHAN KASING', '2026-01-20');

-- Schema: inventory
CREATE SCHEMA IF NOT EXISTS "inventory";


-- Table: inventory.products
CREATE TABLE IF NOT EXISTS "inventory"."products" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "sku" VARCHAR(100),
    "description" TEXT,
    "unit_price" NUMERIC DEFAULT 0.00 NOT NULL,
    "cost_price" NUMERIC,
    "currency" VARCHAR(3) DEFAULT '''KHR'''::character varying NOT NULL,
    "current_stock" INTEGER DEFAULT 0 NOT NULL,
    "low_stock_threshold" INTEGER DEFAULT 10,
    "track_stock" BOOLEAN DEFAULT true NOT NULL,
    "is_active" BOOLEAN DEFAULT true NOT NULL,
    "meta" JSON,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "inventory"."products" ("id", "tenant_id", "name", "sku", "description", "unit_price", "cost_price", "currency", "current_stock", "low_stock_threshold", "track_stock", "is_active", "meta", "created_at", "updated_at") VALUES ('042e3e5d-ad4b-4664-8124-9227915df0c6', '62644a78-bc22-4833-b032-d8f080beb3be', 'Vital-box', 'PROD-0001', '', '10.00', '2000.00', 'USD', 200, 10, True, True, NULL, '2026-01-14T14:35:40.504825+00:00', '2026-01-14T14:35:40.534334+00:00');
INSERT INTO "inventory"."products" ("id", "tenant_id", "name", "sku", "description", "unit_price", "cost_price", "currency", "current_stock", "low_stock_threshold", "track_stock", "is_active", "meta", "created_at", "updated_at") VALUES ('a37fb4e4-bf4e-4fd6-9d4f-28763ead2e1c', '62644a78-bc22-4833-b032-d8f080beb3be', 'Water meter ', 'PROD-002', 'water meter for local', '2000.00', '1000.00', 'KHR', 1000, 0, True, True, NULL, '2026-01-15T02:10:11.753457+00:00', '2026-01-15T13:31:59.093357+00:00');

-- Table: inventory.stock_movements
CREATE TABLE IF NOT EXISTS "inventory"."stock_movements" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "movement_type" VARCHAR(20) NOT NULL,
    "quantity" INTEGER NOT NULL,
    "reference_type" VARCHAR(50),
    "reference_id" VARCHAR(255),
    "notes" TEXT,
    "created_by" UUID,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);
INSERT INTO "inventory"."stock_movements" ("id", "tenant_id", "product_id", "movement_type", "quantity", "reference_type", "reference_id", "notes", "created_by", "created_at") VALUES ('21e4af76-db7e-45f1-ad51-b26a3267d9cd', '62644a78-bc22-4833-b032-d8f080beb3be', '042e3e5d-ad4b-4664-8124-9227915df0c6', 'in_stock', 100, 'initial', NULL, 'Initial stock', '89c1b42a-b7bd-4f51-9a8f-e9089b4682a8', '2026-01-14T14:35:40.547486+00:00');
INSERT INTO "inventory"."stock_movements" ("id", "tenant_id", "product_id", "movement_type", "quantity", "reference_type", "reference_id", "notes", "created_by", "created_at") VALUES ('e793cf92-36cd-4b78-b891-e96bade44c5c', '62644a78-bc22-4833-b032-d8f080beb3be', 'a37fb4e4-bf4e-4fd6-9d4f-28763ead2e1c', 'in_stock', 10000, 'initial', NULL, 'Initial stock', '51e61235-0326-4739-997e-c48fd9e44bcc', '2026-01-15T02:10:11.783536+00:00');
INSERT INTO "inventory"."stock_movements" ("id", "tenant_id", "product_id", "movement_type", "quantity", "reference_type", "reference_id", "notes", "created_by", "created_at") VALUES ('b88018b7-d38c-4ce5-9163-3bdf0d38194f', '62644a78-bc22-4833-b032-d8f080beb3be', 'a37fb4e4-bf4e-4fd6-9d4f-28763ead2e1c', 'adjustment', -19000, 'manual', NULL, NULL, '51e61235-0326-4739-997e-c48fd9e44bcc', '2026-01-15T13:31:59.119957+00:00');

-- Schema: scriptclient
CREATE SCHEMA IF NOT EXISTS "scriptclient";


-- Table: scriptclient.screenshot
CREATE TABLE IF NOT EXISTS "scriptclient"."screenshot" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "file_path" VARCHAR(500),
    "file_url" TEXT,
    "verified" BOOLEAN DEFAULT false NOT NULL,
    "verified_at" TIMESTAMP WITH TIME ZONE,
    "verified_by" UUID,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Schema: audit_sales
CREATE SCHEMA IF NOT EXISTS "audit_sales";


-- Table: audit_sales.sale
CREATE TABLE IF NOT EXISTS "audit_sales"."sale" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "date" DATE NOT NULL,
    "amount" NUMERIC NOT NULL,
    "description" TEXT,
    "category" VARCHAR(100),
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Schema: ads_alert
CREATE SCHEMA IF NOT EXISTS "ads_alert";


-- Table: ads_alert.chat
CREATE TABLE IF NOT EXISTS "ads_alert"."chat" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "platform" VARCHAR(50) NOT NULL,
    "chat_id" VARCHAR(100) NOT NULL,
    "chat_name" VARCHAR(255),
    "is_active" BOOLEAN DEFAULT true NOT NULL,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: ads_alert.promo_status
CREATE TABLE IF NOT EXISTS "ads_alert"."promo_status" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "active" BOOLEAN DEFAULT false NOT NULL,
    "last_sent" TIMESTAMP WITH TIME ZONE,
    "next_scheduled" TIMESTAMP WITH TIME ZONE,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);

-- Table: ads_alert.promotion
CREATE TABLE IF NOT EXISTS "ads_alert"."promotion" (
    "id" UUID DEFAULT gen_random_uuid() NOT NULL,
    "tenant_id" UUID NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "content" TEXT,
    "status" VARCHAR(20) DEFAULT 'draft'::character varying NOT NULL,
    "sent_at" TIMESTAMP WITH TIME ZONE,
    "meta" JSONB DEFAULT '{}'::jsonb,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    PRIMARY KEY ("id")
);